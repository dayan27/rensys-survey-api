const express = require('express');
const router = express.Router();

const { getSurveys,
       getSurvey,
       createSurvey,
       deleteSurvey,
       updateSurvey,
       changeSurveyStatus,
       WSTrial
} = require('../controllers/survey');

router.route('/').get(getSurveys).post(createSurvey);
router.route('/:id').get(getSurvey).delete(deleteSurvey).put(updateSurvey);
router.route('/status/:id').put(changeSurveyStatus);
// router.route('/ws-echo').get(WSTrial)
router.get("/ws/echo", WSTrial)
module.exports = router;